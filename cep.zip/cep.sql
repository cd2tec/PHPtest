-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 29-Set-2021 às 21:54
-- Versão do servidor: 10.4.10-MariaDB
-- versão do PHP: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cep`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

DROP TABLE IF EXISTS `endereco`;
CREATE TABLE IF NOT EXISTS `endereco` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cep` int(10) NOT NULL,
  `logradouro` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `complemento` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `bairro` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `localidade` varchar(20) CHARACTER SET utf8 NOT NULL,
  `uf` varchar(5) CHARACTER SET utf8 NOT NULL,
  `ibge` int(20) DEFAULT NULL,
  `gia` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
  `ddd` int(5) DEFAULT NULL,
  `siafi` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `endereco`
--

INSERT INTO `endereco` (`id`, `cep`, `logradouro`, `complemento`, `bairro`, `localidade`, `uf`, `ibge`, `gia`, `ddd`, `siafi`) VALUES
(7, 35400000, '', '', '', 'Ouro Preto', 'MG', 3146107, '', 31, 4921),
(5, 35324000, '', '', '', 'Entre Folhas', 'MG', 3123858, '', 33, 2663),
(6, 35198000, '', '', '', 'Ipaba', 'MG', 3131158, '', 31, 2665),
(8, 35012260, 'Rua São Sebastião', '', 'Vila Mariana', 'Governador Valadares', 'MG', 3127701, '', 33, 4553),
(9, 35421000, '', '', 'Passagem de Mariana', 'Mariana', 'MG', 3140001, '', 31, 4799),
(10, 35430970, 'Avenida Caetano Marinho 226', '', 'Centro', 'Ponte Nova', 'MG', 3152105, '', 31, 5041);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
